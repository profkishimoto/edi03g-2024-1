
public class Program {

	public static void main(String[] args) {
		
		Deque d = new Deque(2);
		d.insertBack(0);
		d.insertBack(1);
		try {
			d.insertBack(2);
		} catch(RuntimeException e) {
			System.out.println("Não foi possível inserir o valor na deque porque ela está cheia.");
			System.out.println(e.getMessage());
		}
		d.removeBack();
		d.removeBack();
		try {
			d.removeBack();
		} catch(RuntimeException e) {
			System.out.println("Não foi possível remover um valor da deque porque ela está vazia.");
		}

		
		Stack s = new Stack(10);
		for (int i = 0; i < 10; ++i) {
			try {
				s.push(i);
				System.out.println("s.top(): " + s.top());
			} catch(RuntimeException e) {
				System.out.println("Pilha cheia.");
				break;
			}			
		}
		
		while(true) {
			try {
				System.out.println("s.pop(): " + s.pop());
			} catch(RuntimeException e) {
				System.out.println("Pilha vazia.");
				break;
			}
		}
		
		System.out.println("Fim.");
		
	}

}
