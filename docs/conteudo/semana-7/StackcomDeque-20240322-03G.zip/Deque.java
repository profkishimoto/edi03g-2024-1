
public class Deque {

	private static final int DEFAULT_CAPACITY = 32;
	private int first;
	private int last;
	private int count;
	private int data[];
	
	public Deque() {
		this(DEFAULT_CAPACITY);
	}
	
	public Deque(int capacity) {
		data = new int[capacity];
		first = 0;
		last = 0;
		count = 0;
	}
	
	public void insertFront(int value) { }
	
	public void insertBack(int value) {
		if (isFull()) {
			throw new RuntimeException("insertBack(" + value + "): deque cheia.");
		}
		
		data[last] = value;
		last = (last + 1) % data.length;
		++count;
	}
	
	public int removeFront() { return 0; }
	
	public int removeBack() {
		if (isEmpty()) {
			throw new RuntimeException("removeBack(): deque vazia.");
		}
		
		last = (last - 1 + data.length) % data.length;
		int value = data[last];
		data[last] = 0;
		--count;
		
		return value;
	}
	
	public int front() { return 0; }
	
	public int back() {
		if (isEmpty()) {
			throw new RuntimeException("back(): deque vazia.");
		}
		
		return data[(last - 1 + data.length) % data.length];
	}
	
	public boolean isFull() {
		return count == data.length;
	}
	
	public boolean isEmpty() {
		return count == 0;
	}

}
