
public class Stack {

	private static final int DEFAULT_CAPACITY = 32;

	private Deque deque;
	
	public Stack() {
		this(DEFAULT_CAPACITY);
	}
	
	public Stack(int capacity) {
		deque = new Deque(capacity);
	}
	
	public void push(int value) {
		if (isFull()) {
			throw new RuntimeException("push(" + value + "): pilha cheia.");
		}
		
		deque.insertBack(value);
	}
	
	public int pop() {
		if (isEmpty()) {
			throw new RuntimeException("pop(): pilha vazia.");
		}
		
		return deque.removeBack();
	}
	
	public int top() {
		if (isEmpty()) {
			throw new RuntimeException("top(): pilha vazia.");
		}

		return deque.back();
	}
	
	public boolean isFull() {
		return deque.isFull();
	}
	
	public boolean isEmpty() {
		return deque.isEmpty();
	}
	
}
